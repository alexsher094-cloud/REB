#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Launch_main.py - Лаунчер для радиолокационных лабораторных работ
Запускает три отдельных приложения:
    1. LR2-общ.py - ЛЧМ сигнал, код Баркера, произвольный ФКМ
    2. ЛР1 C GUI.py - Анализ функции неопределенности радиолокационных сигналов
    3. lab4_REB.py - ЭПР объектов различной формы
"""

import subprocess
import sys
import os
import time
import threading
from pathlib import Path

import customtkinter as ctk
from tkinter import messagebox


# Конфигурация путей к скриптам
SCRIPT_DIR = Path(__file__).parent.absolute()

SCRIPTS = {
    "LR2-общ.py": {
        "name": "Радиолокационные сигналы - ЛЧМ, Баркер, ФКМ",
        "description": "Моделирование ЛЧМ сигнала, кода Баркера и произвольного фазоманипулированного сигнала\n"
                       "Особенности: добавление шума, согласованный фильтр, анализ эффекта Доплера",
        "icon": "📡",
        "color": "#1e3a5f"
    },
    "ЛР1 C GUI.py": {
        "name": "Анализ функции неопределенности",
        "description": "Анализ функции неопределенности для различных типов сигналов:\n"
                       "прямоугольный импульс, ЛЧМ, код Баркера, М-последовательность,\n"
                       "пачка прямоугольных импульсов, пачка ЛЧМ сигналов",
        "icon": "📊",
        "color": "#2e5a7f"
    },
    "lab4_REB.py": {
        "name": "ЭПР объектов различной формы",
        "description": "Расчет и визуализация эффективной площади рассеяния (ЭПР):\n"
                       "сфера, диск, пластина, конус, двугранный и трёхгранный отражатели,\n"
                       "линза Люнеберга, решётка Ван-Атта",
        "icon": "🔬",
        "color": "#3e6a8f"
    }
}


class ScriptLauncherApp(ctk.CTk):
    """Главное окно лаунчера для запуска Python-скриптов"""
    
    def __init__(self):
        super().__init__()
        
        # Настройка окна
        self.title("Лаунчер лабораторных работ по радиолокации")
        self.geometry("950x750")
        self.minsize(800, 600)
        
        # Настройка внешнего вида
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        
        # Словарь для хранения запущенных процессов
        self.running_processes = {}
        
        # Центрирование окна
        self.center_window()
        
        # Создание интерфейса
        self.setup_ui()
        
        # Проверка наличия скриптов
        self.check_scripts()
        
        # Обработка закрытия окна
        self.protocol("WM_DELETE_WINDOW", self.on_closing)
        
    def center_window(self):
        """Центрирование окна на экране"""
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f'{width}x{height}+{x}+{y}')
        
    def setup_ui(self):
        """Создание пользовательского интерфейса"""
        
        # Основной контейнер
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)   # Заголовок
        self.grid_rowconfigure(1, weight=1)   # Контент
        self.grid_rowconfigure(2, weight=0)   # Статусбар
        
        # ========== Верхняя панель с заголовком ==========
        header_frame = ctk.CTkFrame(self, height=100, corner_radius=0)
        header_frame.grid(row=0, column=0, sticky="ew")
        header_frame.grid_propagate(False)
        
        title_label = ctk.CTkLabel(
            header_frame,
            text="Лабораторные работы по радиолокации",
            font=ctk.CTkFont(size=28, weight="bold"),
            anchor="center"
        )
        title_label.pack(expand=True, pady=(20, 5))
        
        subtitle_label = ctk.CTkLabel(
            header_frame,
            text="Выберите лабораторную работу для запуска",
            font=ctk.CTkFont(size=14),
            text_color="gray70",
            anchor="center"
        )
        subtitle_label.pack(expand=True, pady=(0, 20))
        
        # ========== Основная область со скриптами ==========
        main_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        main_frame.grid(row=1, column=0, sticky="nsew", padx=20, pady=20)
        main_frame.grid_columnconfigure(0, weight=1)
        
        # Создание карточек для каждого скрипта
        self.cards = {}
        
        for i, (script_name, info) in enumerate(SCRIPTS.items()):
            card = self.create_script_card(main_frame, script_name, info, i)
            card.pack(fill="x", pady=10, padx=5)
            self.cards[script_name] = card
            
        # ========== Статусбар ==========
        self.status_frame = ctk.CTkFrame(self, height=45, corner_radius=0)
        self.status_frame.grid(row=2, column=0, sticky="ew")
        self.status_frame.grid_propagate(False)
        
        self.status_label = ctk.CTkLabel(
            self.status_frame,
            text="Готов к работе",
            font=ctk.CTkFont(size=12),
            anchor="w"
        )
        self.status_label.pack(side="left", padx=20, pady=10)
        
        # Кнопка "Выход"
        exit_btn = ctk.CTkButton(
            self.status_frame,
            text="Выход",
            width=80,
            height=32,
            fg_color="#dc2626",
            hover_color="#b91c1c",
            command=self.on_closing
        )
        exit_btn.pack(side="right", padx=20, pady=6)
        
    def create_script_card(self, parent, script_name, info, index):
        """Создание карточки для одного скрипта"""
        
        card = ctk.CTkFrame(parent, corner_radius=12, border_width=1, border_color="#3a3a3a")
        
        # Внутренняя сетка карточки
        card.grid_columnconfigure(0, weight=0)  # Иконка
        card.grid_columnconfigure(1, weight=1)  # Контент
        card.grid_columnconfigure(2, weight=0)  # Кнопки
        
        # Иконка
        icon_label = ctk.CTkLabel(
            card,
            text=info["icon"],
            font=ctk.CTkFont(size=48),
            width=70
        )
        icon_label.grid(row=0, column=0, rowspan=3, padx=(15, 5), pady=10, sticky="n")
        
        # Название
        name_label = ctk.CTkLabel(
            card,
            text=info["name"],
            font=ctk.CTkFont(size=16, weight="bold"),
            anchor="w"
        )
        name_label.grid(row=0, column=1, sticky="w", padx=10, pady=(10, 0))
        
        # Описание
        desc_label = ctk.CTkLabel(
            card,
            text=info["description"],
            font=ctk.CTkFont(size=12),
            text_color="gray70",
            anchor="w",
            justify="left",
            wraplength=500
        )
        desc_label.grid(row=1, column=1, sticky="w", padx=10, pady=(5, 10))
        
        # Статус скрипта (только два состояния: готов/запущен)
        status_label = ctk.CTkLabel(
            card,
            text="● Готов к работе",
            font=ctk.CTkFont(size=11),
            text_color="#22c55e",
            anchor="w"
        )
        status_label.grid(row=2, column=1, sticky="w", padx=10, pady=(0, 10))
        
        # Кнопки управления
        buttons_frame = ctk.CTkFrame(card, fg_color="transparent")
        buttons_frame.grid(row=0, column=2, rowspan=3, padx=15, pady=10, sticky="e")
        
        run_btn = ctk.CTkButton(
            buttons_frame,
            text="Запустить",
            width=120,
            height=38,
            fg_color=info["color"],
            hover_color=self.adjust_brightness(info["color"], -20),
            command=lambda sn=script_name: self.run_script(sn)
        )
        run_btn.pack(pady=5)
        
        # Сохраняем ссылки на элементы для обновления
        card.status_label = status_label
        card.run_button = run_btn
        card.script_path = SCRIPT_DIR / script_name
        card.script_name = script_name
        
        return card
        
    def adjust_brightness(self, hex_color, percent):
        """Изменение яркости цвета"""
        hex_color = hex_color.lstrip('#')
        r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        r = max(0, min(255, r + percent))
        g = max(0, min(255, g + percent))
        b = max(0, min(255, b + percent))
        
        return f"#{r:02x}{g:02x}{b:02x}"
        
    def check_scripts(self):
        """Проверка наличия всех скриптов"""
        missing_scripts = []
        
        for script_name in SCRIPTS.keys():
            script_path = SCRIPT_DIR / script_name
            card = self.cards.get(script_name)
            
            if card:
                if script_path.exists():
                    # Скрипт найден, статус "Готов к работе"
                    card.status_label.configure(
                        text="● Готов к работе",
                        text_color="#22c55e"
                    )
                else:
                    # Скрипт не найден
                    card.status_label.configure(
                        text="● Файл не найден",
                        text_color="#ef4444"
                    )
                    card.run_button.configure(
                        state="disabled",
                        fg_color="#6b7280",
                        text="Файл не найден"
                    )
                    missing_scripts.append(script_name)
                    
        if missing_scripts:
            self.status_label.configure(
                text=f"Предупреждение: не найдены скрипты: {', '.join(missing_scripts)}"
            )
        else:
            self.status_label.configure(text="Готов к работе")
            
    def run_script(self, script_name):
        """Запуск выбранного скрипта в отдельном процессе"""
        script_path = SCRIPT_DIR / script_name
        
        if not script_path.exists():
            messagebox.showerror(
                "Ошибка",
                f"Файл {script_name} не найден!\n\n"
                f"Ожидаемый путь: {script_path}\n\n"
                f"Убедитесь, что все скрипты находятся в одной папке с лаунчером."
            )
            return
            
        # Проверка, не запущен ли уже скрипт
        if script_name in self.running_processes:
            process = self.running_processes[script_name]
            if process.poll() is None:
                # Процесс еще работает
                result = messagebox.askyesno(
                    "Скрипт уже запущен",
                    f"Скрипт '{script_name}' уже запущен.\n\n"
                    f"Запустить еще один экземпляр?"
                )
                if not result:
                    return
            else:
                # Процесс завершился, удаляем из словаря
                del self.running_processes[script_name]
            
        # Обновление статуса
        self.status_label.configure(text=f"Запуск {script_name}...")
        
        # Блокировка кнопки на время запуска
        card = self.cards.get(script_name)
        if card:
            card.run_button.configure(
                state="disabled",
                text="Запуск..."
            )
            card.run_button.update()
            
        # Запуск в отдельном потоке, чтобы не блокировать GUI
        thread = threading.Thread(
            target=self._run_script_thread,
            args=(script_name, script_path, card),
            daemon=True
        )
        thread.start()
        
    def _run_script_thread(self, script_name, script_path, card):
        """Запуск скрипта в отдельном потоке"""
        try:
            # Используем CREATE_NEW_CONSOLE для Windows, чтобы скрипт открывался в новом окне
            if sys.platform == "win32":
                # Для Windows: открываем в новом окне консоли
                process = subprocess.Popen(
                    [sys.executable, str(script_path)],
                    cwd=str(SCRIPT_DIR),
                    creationflags=subprocess.CREATE_NEW_CONSOLE if hasattr(subprocess, 'CREATE_NEW_CONSOLE') else 0,
                    shell=False
                )
            else:
                # Для Linux/Mac: используем обычный запуск
                process = subprocess.Popen(
                    [sys.executable, str(script_path)],
                    cwd=str(SCRIPT_DIR),
                    stdout=None,
                    stderr=None,
                    shell=False
                )
            
            # Сохраняем процесс
            self.running_processes[script_name] = process
            
            # Обновляем UI в главном потоке
            self.after(0, lambda: self._on_script_started(script_name, process, card))
            
            # Ждем завершения процесса в фоне
            def wait_for_process():
                process.wait()
                self.after(0, lambda: self._on_script_finished(script_name, card))
            
            threading.Thread(target=wait_for_process, daemon=True).start()
            
        except Exception as e:
            self.after(0, lambda: self._on_script_error(script_name, card, str(e)))
            
    def _on_script_started(self, script_name, process, card):
        """Обработчик успешного запуска скрипта"""
        self.status_label.configure(text=f"{script_name} - запущен")
        
        if card:
            card.run_button.configure(
                state="normal",
                text="Запустить",
                fg_color="#22c55e",
                hover_color="#16a34a"
            )
            card.status_label.configure(
                text="● Запущен",
                text_color="#f59e0b"
            )
            
    def _on_script_finished(self, script_name, card):
        """Обработчик завершения скрипта - возвращаем статус в 'Готов к работе'"""
        if script_name in self.running_processes:
            del self.running_processes[script_name]
            
        self.status_label.configure(text="Готов к работе")
        
        if card:
            card.run_button.configure(
                state="normal",
                text="Запустить",
                fg_color=SCRIPTS[script_name]["color"],
                hover_color=self.adjust_brightness(SCRIPTS[script_name]["color"], -20)
            )
            card.status_label.configure(
                text="● Готов к работе",
                text_color="#22c55e"
            )
            
    def _on_script_error(self, script_name, card, error_msg):
        """Обработчик ошибки запуска"""
        self.status_label.configure(text="Готов к работе")
        
        messagebox.showerror(
            "Ошибка запуска",
            f"Не удалось запустить {script_name}:\n\n{error_msg}\n\n"
            f"Проверьте, что скрипт не содержит синтаксических ошибок."
        )
        
        if card:
            card.run_button.configure(
                state="normal",
                text="Запустить",
                fg_color=SCRIPTS[script_name]["color"],
                hover_color=self.adjust_brightness(SCRIPTS[script_name]["color"], -20)
            )
            card.status_label.configure(
                text="● Готов к работе",
                text_color="#22c55e"
            )
            
    def on_closing(self):
        """Обработка закрытия главного окна"""
        # Проверяем, есть ли запущенные процессы
        running = []
        for script_name, process in self.running_processes.items():
            if process.poll() is None:
                running.append(script_name)
                
        if running:
            result = messagebox.askyesno(
                "Подтверждение выхода",
                f"Следующие скрипты все еще запущены:\n{', '.join(running)}\n\n"
                f"Они продолжат работу после закрытия лаунчера.\n\n"
                f"Закрыть лаунчер?"
            )
            if not result:
                return
                
        self.destroy()


def main():
    """Точка входа"""
    # Проверка наличия customtkinter
    try:
        import customtkinter
    except ImportError:
        print("Ошибка: Не установлен customtkinter")
        print("Установите его командой: pip install customtkinter")
        sys.exit(1)
        
    # Проверка наличия matplotlib для ЛР1
    try:
        import matplotlib
    except ImportError:
        print("Предупреждение: Не установлен matplotlib")
        print("Установите его командой: pip install matplotlib")
        
    # Проверка наличия scipy для LR2
    try:
        import scipy
    except ImportError:
        print("Предупреждение: Не установлен scipy")
        print("Установите его командой: pip install scipy")
        
    # Проверка наличия numpy
    try:
        import numpy
    except ImportError:
        print("Предупреждение: Не установлен numpy")
        print("Установите его командой: pip install numpy")
        
    # Запуск приложения
    app = ScriptLauncherApp()
    app.mainloop()


if __name__ == "__main__":
    main()